"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Mail, CheckSquare, User, Settings, Phone, Globe, HelpCircle, BarChart3, Edit, Menu, Bell, Calendar, Lock, Grid3x3, Star, CheckCircle, MessageSquare, Flag, Power } from "lucide-react";
import { useRouter } from "next/navigation";

interface Widget {
  id: number;
  title: string;
  content: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const [widgets, setWidgets] = useState<Widget[]>([]);
  const [newWidget, setNewWidget] = useState({ title: "", content: "" });
  const [isWidgetDialogOpen, setIsWidgetDialogOpen] = useState(false);

  const handleLogout = () => {
    router.push("/");
  };

  const addWidget = () => {
    if (newWidget.title && newWidget.content) {
      setWidgets([...widgets, { id: Date.now(), ...newWidget }]);
      setNewWidget({ title: "", content: "" });
      setIsWidgetDialogOpen(false);
    }
  };

  const personalMenu = [
    { icon: Mail, label: "Mesajlar", badge: 12, href: "#" },
    { icon: CheckSquare, label: "Anketler", badge: 0, href: "#" },
    { icon: User, label: "Hesap Ayarları", href: "#" },
    { icon: Settings, label: "Portal Ayarları", href: "#" },
  ];

  const quickLinks = [
    { icon: Phone, label: "Telefon Rehberi", href: "#" },
    { icon: Globe, label: "Web Sayfası", href: "#" },
    { icon: HelpCircle, label: "Destek", href: "#" },
    { icon: BarChart3, label: "Kurumsal Değerlendirme", href: "#" },
  ];

  return (
    <div className="min-h-screen" style={{ background: '#ECEFF1' }}>
      {/* Header - UBYS Style */}
      <header
        className="fixed top-0 left-0 right-0 h-[50px] flex items-center justify-between px-4 text-white font-semibold z-50 shadow-md"
        style={{
          background: '#3D8BB8',
          fontSize: '18px',
          lineHeight: '20px'
        }}
      >
        {/* Sol Menü */}
        <button
          className="flex items-center justify-center hover:opacity-80 transition-opacity"
          style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Sağ İkonlar */}
        <div className="flex items-center" style={{ gap: '15px' }}>
          <button
            className="flex items-center justify-center hover:opacity-80 transition-opacity relative"
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
          >
            <CheckCircle className="w-5 h-5" />
          </button>

          <button
            className="flex items-center justify-center hover:opacity-80 transition-opacity relative"
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
          >
            <Calendar className="w-5 h-5" />
          </button>

          <button
            className="flex items-center justify-center hover:opacity-80 transition-opacity relative"
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
          >
            <MessageSquare className="w-5 h-5" />
            <span
              className="absolute -top-1 -right-1 flex items-center justify-center"
              style={{
                background: '#E45139',
                color: '#FFFFFF',
                fontSize: '10px',
                fontWeight: 600,
                width: '16px',
                height: '16px',
                borderRadius: '50%'
              }}
            >
              12
            </span>
          </button>

          <button
            className="flex items-center justify-center hover:opacity-80 transition-opacity relative"
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
          >
            <Flag className="w-5 h-5" />
          </button>

          <button
            className="flex items-center justify-center hover:opacity-80 transition-opacity relative"
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
          >
            <Lock className="w-5 h-5" />
          </button>

          <button
            className="flex items-center justify-center hover:opacity-80 transition-opacity relative"
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#FFFFFF' }}
          >
            <Grid3x3 className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Wrapper */}
      <div className="flex" style={{ marginTop: '50px' }}>
        {/* Sidebar */}
        <aside className="w-[420px] p-[15px] space-y-[14px]" style={{ background: '#ECEFF1', minHeight: 'calc(100vh - 50px)', marginLeft: '20px' }}>
          {/* User Panel */}
          <Card className="rounded-none" style={{ border: '1px solid #DDDDDD', background: '#FFFFFF', position: 'relative' }}>
            <CardContent style={{ padding: '12px 16px' }}>
              {/* Çıkış Butonu - Sağ Üst */}
              <button
                onClick={handleLogout}
                className="hover:opacity-70 transition-opacity flex items-center justify-center"
                style={{
                  position: 'absolute',
                  top: '12px',
                  right: '12px',
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: '#E45139',
                  width: '32px',
                  height: '32px',
                  padding: 0
                }}
                title="Çıkış Yap"
              >
                <Power className="w-5 h-5" strokeWidth={2.5} />
              </button>

              <div className="flex items-center" style={{ gap: '12px', marginBottom: '12px' }}>
                <div style={{
                  width: '65px',
                  height: '65px',
                  borderRadius: '50%',
                  overflow: 'hidden',
                  flexShrink: 0,
                  border: '2px solid #E0E0E0'
                }}>
                  <img
                    src="https://ext.same-assets.com/864185613/2608892240.jpeg"
                    alt="Ömer Yasin Buyruk"
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      objectPosition: 'center 15%'
                    }}
                  />
                </div>
                <p style={{ fontSize: '14px', fontWeight: 600, color: '#333333', flex: 1, marginTop: '-8px', paddingRight: '30px' }}>
                  ÖMER YASİN BUYRUK
                </p>
              </div>
              <div className="flex items-center" style={{ gap: '8px' }}>
                <select
                  style={{
                    fontSize: '12px',
                    fontWeight: 400,
                    color: '#555555',
                    border: '1px solid #DDDDDD',
                    borderRadius: '3px',
                    padding: '4px 8px',
                    background: '#FFFFFF',
                    cursor: 'pointer',
                    flex: 1
                  }}
                >
                  <option>Öğrenciler</option>
                  <option>Akademik Personel</option>
                  <option>İdari Personel</option>
                </select>
                <button
                  style={{
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <Star className="w-4 h-4" style={{ color: '#000000', fill: '#000000' }} />
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Kişisel Menu */}
          <Card className="rounded-none" style={{ border: '1px solid #DDDDDD', borderTop: '3px solid #40B7C7', background: '#FFFFFF' }}>
            <CardHeader style={{ padding: '10px 15px', borderBottom: '1px solid #EFEFEF' }}>
              <CardTitle style={{ fontSize: '18px', fontWeight: 600, color: '#888888' }}>Kişisel</CardTitle>
            </CardHeader>
            <CardContent className="p-0" style={{ paddingBottom: '10px' }}>
              {personalMenu.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  className="flex items-center hover:bg-gray-50 transition-colors group"
                  style={{
                    gap: '13px',
                    padding: '11px 15px',
                  }}
                >
                  <item.icon
                    className="w-5 h-5 group-hover:opacity-80"
                    style={{ color: '#97B9C9', width: '24px' }}
                  />
                  <span
                    className="flex-1 group-hover:opacity-80"
                    style={{ fontSize: '14px', fontWeight: 400, color: '#555555' }}
                  >
                    {item.label}
                  </span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <Badge
                      variant="destructive"
                      style={{
                        background: '#E45139',
                        color: '#FFFFFF',
                        fontSize: '11px',
                        padding: '2px 6px',
                        borderRadius: '10px'
                      }}
                    >
                      {item.badge}
                    </Badge>
                  )}
                </a>
              ))}
            </CardContent>
          </Card>

          {/* Hızlı Linkler */}
          <Card className="rounded-none" style={{ border: '1px solid #DDDDDD', borderTop: '3px solid #D6D0AC', background: '#FFFFFF' }}>
            <CardHeader style={{ padding: '10px 15px', borderBottom: '1px solid #EFEFEF' }}>
              <CardTitle style={{ fontSize: '18px', fontWeight: 600, color: '#888888' }}>Hızlı Linkler</CardTitle>
            </CardHeader>
            <CardContent className="p-0" style={{ paddingBottom: '10px' }}>
              {quickLinks.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  className="flex items-center hover:bg-gray-50 transition-colors group"
                  style={{
                    gap: '13px',
                    padding: '11px 15px',
                  }}
                >
                  <item.icon
                    className="w-5 h-5 group-hover:opacity-80"
                    style={{ color: '#97B9C9', width: '24px' }}
                  />
                  <span
                    className="group-hover:opacity-80"
                    style={{ fontSize: '14px', fontWeight: 400, color: '#555555' }}
                  >
                    {item.label}
                  </span>
                </a>
              ))}
            </CardContent>
          </Card>

          {/* Bilgilendirmeler */}
          <Card className="rounded-none" style={{ border: '1px solid #DDDDDD', borderTop: '3px solid #85BFE3', background: '#FFFFFF' }}>
            <CardHeader style={{ padding: '10px 15px', borderBottom: '1px solid #EFEFEF' }}>
              <CardTitle style={{ fontSize: '18px', fontWeight: 600, color: '#888888' }}>Bilgilendirmeler</CardTitle>
            </CardHeader>
            <CardContent style={{ padding: '10px 15px' }}>
              <p style={{ fontSize: '14px', color: '#777777' }}>Şu anda bilgilendirme yok.</p>
            </CardContent>
          </Card>
        </aside>

        {/* Main Content */}
        <main className="flex-1 space-y-[14px]" style={{ padding: '15px 20px' }}>
          {/* Kişisel Kısayollar */}
          <Card className="rounded-none" style={{ border: '1px solid #DDDDDD', background: '#FFFFFF' }}>
            <CardHeader style={{ padding: '10px 15px', borderBottom: '1px solid #EFEFEF' }}>
              <div className="flex items-center justify-between">
                <CardTitle style={{ fontSize: '18px', fontWeight: 600, color: '#888888' }}>
                  Kişisel Kısayollar
                </CardTitle>
                <div className="flex gap-[6px]">
                  <button
                    className="rounded-full flex items-center justify-center"
                    style={{
                      width: '22px',
                      height: '22px',
                      background: '#3D8BB8',
                      color: '#FFFFFF',
                      border: 'none',
                      fontSize: '11px',
                      cursor: 'pointer'
                    }}
                  >
                    <Edit className="w-[11px] h-[11px]" />
                  </button>
                </div>
              </div>
            </CardHeader>
            <CardContent style={{ padding: '10px 15px' }}>
            </CardContent>
          </Card>

          {/* Widgets */}
          {widgets.map((widget) => (
            <Card key={widget.id} className="rounded-none" style={{ border: '1px solid #DDDDDD', background: '#FFFFFF' }}>
              <CardHeader style={{ padding: '10px 15px', borderBottom: '1px solid #EFEFEF' }}>
                <CardTitle style={{ fontSize: '18px', fontWeight: 600, color: '#333333' }}>
                  {widget.title}
                </CardTitle>
              </CardHeader>
              <CardContent style={{ padding: '10px 15px' }}>
                <p style={{ fontSize: '14px', color: '#555555' }}>{widget.content}</p>
              </CardContent>
            </Card>
          ))}

          {/* Add Widget Button */}
          <Card className="rounded-none" style={{ border: '1px solid #DDDDDD', background: '#FFFFFF' }}>
            <CardContent style={{ padding: '10px 15px' }}>
              <Dialog open={isWidgetDialogOpen} onOpenChange={setIsWidgetDialogOpen}>
                <DialogTrigger asChild>
                  <button
                    style={{
                      width: '100%',
                      background: '#3D8BB8',
                      color: '#FFFFFF',
                      padding: '8px 14px',
                      borderRadius: '3px',
                      fontSize: '14px',
                      fontWeight: 600,
                      border: 'none',
                      cursor: 'pointer'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#31708F'}
                    onMouseLeave={(e) => e.currentTarget.style.background = '#3D8BB8'}
                  >
                    + Yeni Widget Ekle
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle style={{ fontSize: '20px', fontWeight: 600 }}>Yeni Widget Ekle</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-4">
                    <div>
                      <label style={{ fontSize: '14px', fontWeight: 600, marginBottom: '8px', display: 'block' }}>
                        Widget Başlığı
                      </label>
                      <Input
                        value={newWidget.title}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewWidget({ ...newWidget, title: e.target.value })}
                        placeholder="Widget başlığı"
                      />
                    </div>
                    <div>
                      <label style={{ fontSize: '14px', fontWeight: 600, marginBottom: '8px', display: 'block' }}>
                        İçerik
                      </label>
                      <Input
                        value={newWidget.content}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewWidget({ ...newWidget, content: e.target.value })}
                        placeholder="Widget içeriği"
                      />
                    </div>
                    <button
                      onClick={addWidget}
                      style={{
                        width: '100%',
                        background: '#3D8BB8',
                        color: '#FFFFFF',
                        padding: '8px 14px',
                        borderRadius: '3px',
                        fontSize: '14px',
                        fontWeight: 600,
                        border: 'none',
                        cursor: 'pointer'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.background = '#31708F'}
                      onMouseLeave={(e) => e.currentTarget.style.background = '#3D8BB8'}
                    >
                      Ekle
                    </button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
